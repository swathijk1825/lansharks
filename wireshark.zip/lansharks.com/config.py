# config.py
DATABASE_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'P@ssw0rd',
    'database': 'python'
}

CSV_FILE_PATH_poision = '/var/www/lansharks.com/logs/sample.csv'
SQL_TABLE_NAME_INCIDENT = 'incidents'
